﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ProjectPegawai
{
    public partial class FrmPegawai : Form
    {
        // membuat objek collection dengan nama daftarPegawai
        private List<Pegawai> daftarPegawai = new List<Pegawai>();

        public FrmPegawai()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        // atur kolom listview
        private void InisialisasiListView()
        {
            // PERINTAH: lengkapi kode untuk menambahkan kolom di listview
        }

        private void ResetForm()
        {
            // PERINTAH: lengkapi kode untuk mereset form input
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            // PERINTAH: lengkapi kode untuk menambahkan data penjualan ke dalam collection

            var msg = "Data pegawai berhasil disimpan.";

            // tampilkan dialog informasi
            MessageBox.Show(msg, "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);            

            // tampilkan pegawai ke listview
            TampilkanData();

            // kosongkan form input
            ResetForm();
        }

        private void TampilkanData()
        {
            // kosongkan data listview
            lvwPegawai.Items.Clear();

            // PERINTAH: lengkapi kode untuk menampilkan data penjualan yang ada di dalam collection ke listview
        }
    }
}
