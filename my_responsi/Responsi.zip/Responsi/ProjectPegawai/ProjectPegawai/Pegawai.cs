﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPegawai
{
    public class Pegawai
    {
        // PERINTAH: lengkapi property class pegawai, sesuai petunjuk soal
    }
}
