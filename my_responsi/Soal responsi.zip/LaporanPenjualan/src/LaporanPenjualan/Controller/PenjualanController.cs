﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaporanPenjualan.Controller
{
    public class PenjualanController
    {
        private PenjualanRestApiRepository _repository;

        public PenjualanController()
        {
            _repository = new PenjualanRestApiRepository();
        }

        public List<Penjualan> ReadAll()
        {
            return _repository.ReadAll();
        }

        public List<Penjualan> ReadByBulan(string bulan)
        {
            return _repository.ReadByBulan(bulan);
        }

        public List<Penjualan> ReadByNamaBarang(string namaBarang)
        {
            return _repository.ReadByNamaBarang(namaBarang);
        }

        public List<Penjualan> ReadByKodeBarang(string kodeBarang)
        {
            return _repository.ReadByKodeBarang(kodeBarang);
        }
    }
}
