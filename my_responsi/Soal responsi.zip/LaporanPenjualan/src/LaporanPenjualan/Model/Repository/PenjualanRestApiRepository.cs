﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaporanPenjualan.Model.Repository
{
    public class PenjualanRestApiRepository
    {
        /// <summary>
        /// Method untuk menampilkan semua data penjualan
        /// </summary>
        /// <returns>Object collection dari penjualan</returns>
        public List<Penjualan> ReadAll()
        {
            // lengkapi kode untuk method ReadAll
        }

        /// <summary>
        /// Method untuk pencarian data penjualan berdasarkan nama bulan
        /// </summary>
        /// <param name="bulan"></param>
        /// <returns>Object collection dari penjualan</returns>
        public List<Penjualan> ReadByBulan(string bulan)
        {
            // lengkapi kode untuk method ReadByBulan
        }

        /// <summary>
        /// Method untuk pencarian data penjualan berdasarkan nama barang
        /// </summary>
        /// <param name="namaBarang"></param>
        /// <returns>Object collection dari penjualan</returns>
        public List<Penjualan> ReadByNamaBarang(string namaBarang)
        {
            // lengkapi kode untuk method ReadByNamaBarang
        }

        /// <summary>
        /// Method untuk pencarian data penjualan berdasarkan kode barang
        /// </summary>
        /// <param name="kodeBarang"></param>
        /// <returns>Object collection dari penjualan</returns>
        public List<Penjualan> ReadByKodeBarang(string kodeBarang)
        {
            // lengkapi kode untuk method ReadByKodeBarang
        }
    }
}
