﻿using LaporanPenjualan.Controller;
using LaporanPenjualan.Model.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaporanPenjualan.View
{
    public partial class FrmPencarian : Form
    {
        public FrmPencarian()
        {
            InitializeComponent();
            
            InisialisasiListView();
            cmbFilter.SelectedIndex = 0;
        }

        private void InisialisasiListView()
        {
            lvwLaporan.View = System.Windows.Forms.View.Details;
            lvwLaporan.FullRowSelect = true;
            lvwLaporan.GridLines = true;

            lvwLaporan.Columns.Add("No.", 40, HorizontalAlignment.Center);
            lvwLaporan.Columns.Add("Bulan", 100, HorizontalAlignment.Left);
            lvwLaporan.Columns.Add("Kode Barang", 100, HorizontalAlignment.Left);
            lvwLaporan.Columns.Add("Nama Barang", 750, HorizontalAlignment.Left);
            lvwLaporan.Columns.Add("Jumlah", 70, HorizontalAlignment.Center);
            lvwLaporan.Columns.Add("Harga", 100, HorizontalAlignment.Right);
            lvwLaporan.Columns.Add("Sub Total", 150, HorizontalAlignment.Right);
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            // lengkapi kode untuk button cari
        }
    }
}
